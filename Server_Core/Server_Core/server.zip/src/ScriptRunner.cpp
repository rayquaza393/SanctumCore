﻿#include "ScriptRunner.hpp"
#include <sstream>
#include <iostream>
#include <windows.h>
#include <vector>
#include <stdexcept>

nlohmann::json ScriptRunner::RunScript(const std::string& scriptName, const nlohmann::json& inputJson)
{
    std::string input = inputJson.dump();
    std::string command = "node ./extensions/" + scriptName + ".js";

    SECURITY_ATTRIBUTES saAttr{};
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = TRUE;

    HANDLE stdinRead = NULL, stdinWrite = NULL;
    HANDLE stdoutRead = NULL, stdoutWrite = NULL;

    // Create pipes for stdin and stdout
    if (!CreatePipe(&stdinRead, &stdinWrite, &saAttr, 0))
        throw std::runtime_error("Failed to create stdin pipe.");
    if (!CreatePipe(&stdoutRead, &stdoutWrite, &saAttr, 0))
        throw std::runtime_error("Failed to create stdout pipe.");

    // Ensure the write handle to stdin is not inherited
    SetHandleInformation(stdinWrite, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(stdoutRead, HANDLE_FLAG_INHERIT, 0);

    PROCESS_INFORMATION pi{};
    STARTUPINFOA si{};
    si.cb = sizeof(STARTUPINFOA);
    si.dwFlags |= STARTF_USESTDHANDLES;
    si.hStdInput = stdinRead;
    si.hStdOutput = stdoutWrite;
    si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    std::cout << "[ScriptRunner] Launching: " << command << "\n";

    std::vector<char> cmdBuffer(command.begin(), command.end());
    cmdBuffer.push_back('\0');

    if (!CreateProcessA(nullptr, cmdBuffer.data(), nullptr, nullptr, TRUE, 0, nullptr, nullptr, &si, &pi))
        throw std::runtime_error("Failed to create script process.");

    // Close unused handles
    CloseHandle(stdinRead);
    CloseHandle(stdoutWrite);

    // Write JSON input to script
    DWORD bytesWritten;
    if (!WriteFile(stdinWrite, input.c_str(), static_cast<DWORD>(input.length()), &bytesWritten, nullptr))
        throw std::runtime_error("Failed to write to script stdin.");

    CloseHandle(stdinWrite);

    // Read script output
    char buffer[4096];
    DWORD bytesRead;
    std::ostringstream result;

    while (ReadFile(stdoutRead, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0)
    {
        buffer[bytesRead] = '\0';
        result << buffer;
    }

    CloseHandle(stdoutRead);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);

    std::string rawOutput = result.str();
    std::cout << "[ScriptRunner] Raw Output: " << rawOutput << "\n";

    // Parse only valid JSON portion
    try {
        size_t start = rawOutput.find('{');
        size_t end = rawOutput.rfind('}');
        if (start == std::string::npos || end == std::string::npos || end <= start)
            throw std::runtime_error("Could not locate valid JSON object in script output.");

        std::string cleanJson = rawOutput.substr(start, end - start + 1);
        return nlohmann::json::parse(cleanJson);
    }
    catch (const std::exception& e) {
        std::cerr << "[ScriptRunner] JSON parse failed: " << e.what() << "\n";
        std::cerr << "[ScriptRunner] Raw output: " << rawOutput << "\n";
        throw std::runtime_error("Script output is not valid JSON.");
    }
}
