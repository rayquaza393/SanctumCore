#pragma once

#include <string>

struct Room {
    std::string name;
    std::string scene;
    std::string roomType;
    int maxUsers;
};
