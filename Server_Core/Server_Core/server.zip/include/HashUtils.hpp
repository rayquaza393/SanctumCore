#pragma once
#include <string>

namespace HashUtils {
    std::string SHA256(const std::string& input);
}
